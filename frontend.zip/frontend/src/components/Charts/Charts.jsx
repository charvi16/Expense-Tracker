import "./Charts.css";

export default function Charts() {
  return (
    <div className="chart-box">
      <h3>Spending Overview</h3>
      <div className="fake-chart"></div>
    </div>
  );
}
