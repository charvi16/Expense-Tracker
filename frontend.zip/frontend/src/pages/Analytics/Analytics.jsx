import useFetch from "../../hooks/useFetch";
import "./Analytics.css";

export default function Analytics(){

  const { data, loading } = useFetch("/analytics");

  if(loading) return <main className="page">Loading...</main>;

  return(
    <main className="page analytics-page">

      <h1>Analytics</h1>

      <section className="row">
        {data.monthlySpendingChart && (
          <div className="chart-card">Monthly Chart</div>
        )}

        {data.categoryChart && (
          <div className="chart-card">Category Chart</div>
        )}
      </section>

      <section className="row">
        {data.dailyTrendChart && (
          <div className="chart-card tall">Daily Trend</div>
        )}
      </section>

    </main>
  )
}
