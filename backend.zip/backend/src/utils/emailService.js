export const sendEmail = async (to, subject, text) => {
  // connect Resend / Nodemailer later
  console.log("Mock email to", to, ":", subject);
};
