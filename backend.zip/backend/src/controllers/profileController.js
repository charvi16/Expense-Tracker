import User from "../models/User.js";

export const getProfile = async (req, res) => {
  res.json(req.user);
};

export const updateProfile = async (req, res) => {
  const { name, currency } = req.body;
  req.user.name = name || req.user.name;
  req.user.currency = currency || req.user.currency;
  await req.user.save();
  res.json(req.user);
};

export const uploadPhoto = async(req, res) => {
    req.user.image = "/uploads/profile/" + req.file.filename;

  await req.user.save();

  res.json({ image: req.user.image });
};
