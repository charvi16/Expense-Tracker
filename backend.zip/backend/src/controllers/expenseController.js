import Expense from '../models/Expense.js';

export const createExpense = async (req, res) => {
  try {
    const { amount, category, description, paymentMethod, date, isRecurring } = req.body;

    const expense = await Expense.create({
      user: req.user._id,
      amount,
      category,
      description : notes || description,
      paymentMethod : method,
      date,
      isRecurring
    });

    res.status(201).json(expense);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create expense' });
  }
};

export const getExpenses = async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user._id }).sort({ date: -1 });
    res.json(expenses);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch expenses' });
  }
};
