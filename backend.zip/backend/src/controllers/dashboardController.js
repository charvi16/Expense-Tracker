export const getDashboardData = async (req, res) => {
  try {
    // return placeholders for now
    res.json({
      totalBalance: null,
      monthSpend: null,
      topCategory: null,
      avgDaily: null,
      monthEndExpected: null,
      projectedSavings: null,
      aiInsights: []
    });
  } catch (err) {
    console.error("DASHBOARD ERROR:", err);
    res.status(500).json({ message: "Dashboard fetch failed" });
  }
};
