export default async function cashflowPredictor(userId) {
  return { nextMonthSpending: 25000 };
}
