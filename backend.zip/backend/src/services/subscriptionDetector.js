export default async function subscriptionDetector(userId) {
  // could scan recurring expenses in future
  return [];
}
